AGENCY HOTEL — UPDATE WEBSITE

Isi paket:
- index.html
- assets/therapist-lisa.jpg
- assets/therapist-dea.jpg
- assets/qris-agency-hotel.jpg

PEMBAYARAN YANG SUDAH DIISI
- Bank: OCBC NISP
- No. rekening: 940810293248
- Nama pemilik: Winda Sintia
- QRIS: gambar yang Anda upload

CARA PASANG
1. Backup index.html lama.
2. Upload index.html dari paket ini ke repository GitHub Pages.
3. Upload folder assets beserta tiga gambar di dalamnya.
4. Pastikan struktur:
   index.html
   assets/therapist-lisa.jpg
   assets/therapist-dea.jpg
   assets/qris-agency-hotel.jpg

CATATAN
- QRIS pada website menampilkan nama merchant yang terlihat pada gambar.
- Verifikasi pembayaran otomatis belum dibuat; pelanggan tetap melakukan konfirmasi melalui WhatsApp.
